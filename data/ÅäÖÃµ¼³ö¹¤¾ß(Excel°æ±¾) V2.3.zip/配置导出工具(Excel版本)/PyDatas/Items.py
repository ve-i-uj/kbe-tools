﻿# -*- coding utf-8 -* -

datas={
1001:{ "int":1001, "float":0, "bool":0, "tupleInt":[1,2,3,4], "tupleIntL":[[1,2,3]], "tupleStr":['a','b','c','d'], "tupleStrL":[['a','b','c']], "tupleFloat":[0.1,0.0,0.3,4.1], "tupleFloatL":[[0.1,0.0,0.3,4.1]], "object":[{"0":[1],"1":[2]}], "pos2D":[1.1,2], "pos3D":[1.1,2,50], "dict":{"1":[2,3,4,5]}},
1002:{ "int":1002, "float":0.1, "bool":1, "tupleInt":[], "tupleIntL":[], "tupleStr":[], "tupleStrL":[], "tupleFloat":[], "tupleFloatL":[], "object":[{"0":[1,2]}], "pos2D":[0,-50], "pos3D":[0,-50,0.1], "dict":{"1":[2,3], "10":[20,30,40,50]}},
1003:{ "int":1003, "float":1.5, "bool":1, "tupleInt":[1], "tupleIntL":[[1]], "tupleStr":['a'], "tupleStrL":[['a']], "tupleFloat":[0.1], "tupleFloatL":[[0.1]], "object":[{"0":[1]},{"0":[2]}], "pos2D":[0,-0.1], "pos3D":[0,-0.1,50], "dict":{}},
1004:{ "int":1004, "float":0, "bool":0, "tupleInt":[1,2,3,4], "tupleIntL":[[1,2],[3,4]], "tupleStr":['a','b','c','d'], "tupleStrL":[['a','b'],['c','d']], "tupleFloat":[0.1,0.2,0.3,4.5], "tupleFloatL":[[0.1,0.0],[0.0,4]], "object":[{"0":[1],"1":[2,3]}, {"0":[2,3]}], "pos2D":[], "pos3D":[], "dict":{}},
1005:{ "int":1005, "float":0, "bool":0, "tupleInt":[], "tupleIntL":[[1],[3]], "tupleStr":[], "tupleStrL":[['a'],['c']], "tupleFloat":[], "tupleFloatL":[[0.1],[3.5]], "object":[{"0":[1],"1":[2,3]}], "pos2D":[], "pos3D":[], "dict":{}},
1006:{ "int":1006, "float":0, "bool":0, "tupleInt":[], "tupleIntL":[[1],[3,4]], "tupleStr":[], "tupleStrL":[['a'],['c','d']], "tupleFloat":[], "tupleFloatL":[[0.0],[3,0.0]], "object":[], "pos2D":[], "pos3D":[], "dict":{}}
}

allDatas = {
    "表":datas,
}





